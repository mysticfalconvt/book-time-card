export{B as BookTimeCard}from"./book-time-card-8c3c69e9.js";
